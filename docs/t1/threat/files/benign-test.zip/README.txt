Benign test archive for URL-sandbox QA. No payload.
